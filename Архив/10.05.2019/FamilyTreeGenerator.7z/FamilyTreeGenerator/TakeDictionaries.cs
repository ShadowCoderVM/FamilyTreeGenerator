﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TreeСourseWork
{
    public partial class TakeDictionaries : Form
    {
        public TakeDictionaries()
        {
            InitializeComponent();

            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.InitialDirectory = "F:\\Users\\Sergei\\source\\repos\\TreeСourseWork\\FamilyTreeGenerator\\resources";
            openFileDialog.Filter = "табличные файлы  (*.csv)|*.csv|Все файлы (*.*)|*.*";
            buttonCansel.DialogResult = DialogResult.Cancel;
        }

        public string pathMaleNamesPathronic;
        public string pathFemalyNames;
        public string pathSurnames;

        private void TakeFileMaleNamesAndPathronic(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pathMaleNamesPathronic = openFileDialog.FileName;
                textBoxMaleNamesAndPathronic.Text = pathMaleNamesPathronic;
            }
        }

        private void TakeFileFemalеNames(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pathFemalyNames = openFileDialog.FileName;
                textBoxFemaleNames.Text = pathFemalyNames;
            }
        }

        private void TakeFileSurname(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pathSurnames = openFileDialog.FileName;
                textBoxSurname.Text = pathSurnames;
            }
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            if (pathMaleNamesPathronic != null | pathFemalyNames != null | pathSurnames != null)
            {
                this.DialogResult = DialogResult.OK;
            }
        }


    }
}
