﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TreeСourseWork.TreeGeneratorFiles
{
    class GenderDictionaries
    {
        public List<string> Males;
        public List<string> Female;
        // List<string> menpatronymic;
        public GenderDictionaries()
        {
            Males = new List<string>();
            Female = new List<string>();
        }
        public void Clear()
        {
            Males.Clear();
            Female.Clear();
        }
    }
}
