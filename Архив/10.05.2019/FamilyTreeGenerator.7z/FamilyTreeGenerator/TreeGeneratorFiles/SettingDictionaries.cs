﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TreeСourseWork.TreeGeneratorFiles
{
    internal class SettingDictionaries
    {
        public SettingDictionary MaleNames;
        public SettingDictionary FemaleNames;
        public SettingDictionary MaleSurnames;
        public SettingDictionary FemaleSurnames;
        //public SettingDictionary Pathronic;
        public SettingDictionaries()
        {
        }
    }
}
