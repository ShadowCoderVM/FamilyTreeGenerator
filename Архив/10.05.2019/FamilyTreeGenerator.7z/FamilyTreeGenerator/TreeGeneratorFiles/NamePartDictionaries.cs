﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TreeСourseWork.TreeGeneratorFiles
{
    class NamePartDictionaries
    {
        public GenderDictionaries Names;
        public GenderDictionaries Surnames;
        public NamePartDictionaries()
        {
            Names = new GenderDictionaries();
            Surnames = new GenderDictionaries();
        }
        public void Clear()
        {
            Names.Clear();
            Surnames.Clear();
        }
    }
}
