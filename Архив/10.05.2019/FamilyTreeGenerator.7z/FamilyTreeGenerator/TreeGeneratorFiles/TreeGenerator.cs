﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace TreeСourseWork.TreeGeneratorFiles
{
    class TreeGenerator
    {
        private string pathMaleNamesAndPathronic;
        private string pathFemaleNames;
        private string pathSurnames;
        private int maxDepth;
        private List<string> LogList;
        NamePartDictionaries dictionaries;
        SettingDictionaries settingDictionaries;


        private enum Gender
        {
            Man,
            Woman
        }



        public TreeGenerator(string pathMaleNamesAndPathronic, string pathFemaleNames, string pathSurnames, int maxDepth)
        {

            this.pathMaleNamesAndPathronic = pathMaleNamesAndPathronic;
            this.pathFemaleNames = pathFemaleNames;
            this.pathSurnames = pathSurnames;
            this.maxDepth = maxDepth;
            dictionaries = new NamePartDictionaries();
            LogList = new List<string>();

            settingDictionaries = new SettingDictionaries
            {
                MaleNames = new SettingDictionary(0, 1),
                FemaleNames = new SettingDictionary(0, 1),
                MaleSurnames = new SettingDictionary(0, 2),
                FemaleSurnames = new SettingDictionary(1, 2)
            };
            LoadDictionaries();
            //settingDictionaries.Pathronic = new SettingDictionary(0, 2);
        }
        public void GenerateTree(TreeNode MainNode)
        {

            TreeNode node = MainNode;
            if (node.Level < maxDepth)
            {
                node.Nodes.Add(GenerateFullName(Gender.Man));
                GenerateTree(node.FirstNode);
                node.Nodes.Add(GenerateFullName(Gender.Woman));
                GenerateTree(node.LastNode);
            }
            WriteLog();
        }
        private string GenerateFullName(Gender gender)
        {

            string FullName = "";
            string name = "";
            string family = "";
            Thread.Sleep(20);

            int idName = GenerateRandomId(gender, dictionaries.Names);
            int idFamily = GenerateRandomId(gender, dictionaries.Surnames);
            LogList.Add(gender + " idName = " + idName + " idFamyly = " + idFamily);

            if (gender == Gender.Man)
            {
                name = dictionaries.Names.Males[idName];
                family = dictionaries.Surnames.Males[idFamily];
            }
            else if (gender == Gender.Woman)
            {
                name = dictionaries.Names.Female[idName];
                family = dictionaries.Surnames.Female[idFamily];

            }
            FullName = name + " " + family;
            return FullName;

        }

        private void WriteLog()
        {
            string path = "F:\\Users\\Sergei\\source\\repos\\TreeСourseWork\\FamilyTreeGenerator\\resources\\log.txt";
            using (StreamWriter sw = new StreamWriter(path))
            {
                foreach (string x in LogList)
                {
                    sw.WriteLine(x);
                }
                

            }

            List<string> MalesNames = dictionaries.Names.Males;
            List<string> FemalesNames = dictionaries.Names.Female;
            List<string> MalesSurnames = dictionaries.Surnames.Males;
            List<string> FemaleSurnames = dictionaries.Surnames.Female;

        }

        private int GenerateRandomId(Gender gender, GenderDictionaries namePart)
        {
            int max = 0;
            if (gender == Gender.Man)
            {
                max = namePart.Males.Count;
            }
            else if (gender == Gender.Woman)
            {
                max = namePart.Female.Count;
            }
            Random rand = new Random();
            return rand.Next(max);
        }
        private void LoadDictionaries()
        {
            LoadDictionary(pathMaleNamesAndPathronic, dictionaries.Names.Males, settingDictionaries.MaleNames);
            LoadDictionary(pathFemaleNames, dictionaries.Names.Female, settingDictionaries.FemaleNames);

            LoadDictionary(pathSurnames, dictionaries.Surnames.Males, settingDictionaries.MaleSurnames);
            LoadDictionary(pathSurnames, dictionaries.Surnames.Female, settingDictionaries.FemaleSurnames);
        }
        private void LoadDictionary(string path, List<string> namePart, SettingDictionary settingDictionary)
        {
            string text;
            using (StreamReader sw = new StreamReader(path, Encoding.Default))
            {
                text = sw.ReadToEnd();
            }
            ParseCSV(text, namePart, settingDictionary);
        }

        private void ParseCSV(String text, List<string> namePart, SettingDictionary settingDictionary)
        {
            namePart.Clear();

            text = text.Replace("\r\n", "'");
            string[] ManyText = text.Split(new char[] { '\'', ';' });

            for (int i = settingDictionary.Offset; i < ManyText.Length - settingDictionary.EndOffset; i += settingDictionary.RowOffset)
            {
                namePart.Add(ManyText[i]);
            }
            
        }
    }
}