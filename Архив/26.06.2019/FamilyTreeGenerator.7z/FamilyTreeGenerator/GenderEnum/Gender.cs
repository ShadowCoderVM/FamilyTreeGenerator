﻿namespace FamilyTreeGenerator.GenderEnum
{
    public enum Gender
    {
        Man,
        Woman
    }
}
