﻿namespace FamilyTreeGenerator.TreeGeneratorFiles
{
    public class ParseSettings
    {
        public ParseTableSettings MaleNames;
        public ParseTableSettings FemaleNames;
        public ParseTableSettings MaleSurnames;
        public ParseTableSettings FemaleSurnames;
        public ParseTableSettings MalePathronic;
        public ParseTableSettings FemalePathronic;
        public ParseSettings(){ }
    }
}
