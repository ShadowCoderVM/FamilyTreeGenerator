﻿namespace FamilyTreeGenerator
{
    public class FilePaths
    {
        public string MaleNamesAndPathronic;
        public string FemaleNames;
        public string Surnames;
    }
}
